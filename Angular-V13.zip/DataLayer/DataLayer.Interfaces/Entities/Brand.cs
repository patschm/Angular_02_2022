namespace DataLayer.Interfaces.Entities
{
    public class Brand
    {
        public int ID { get; set; }
        public string? Name { get; set; }
    }
}