namespace DataLayer.Interfaces.Entities
{
    public class Specification 
    {
        public string? Key { get; set; }
        public object? Value { get; set; }
    }
}