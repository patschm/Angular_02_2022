export class Brand
{
    public id:Number;
    public name:String;

    constructor()
    {
        this.id = 0;
        this.name = "";
    }
}
