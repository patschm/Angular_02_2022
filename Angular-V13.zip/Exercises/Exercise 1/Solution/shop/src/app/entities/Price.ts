export class Price
{
    public productID: Number;
    public basePrice: Number;
    public shopName: String;
    
    constructor()
    {
        this.productID = 0;
        this.basePrice = 0;
        this.shopName = "";
    }
}