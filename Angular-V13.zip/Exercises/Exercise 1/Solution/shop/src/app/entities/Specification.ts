export class Specification
{
    public key:String;
    public value:String;

    constructor(){
        this.key = "";
        this.value = "";
    }
}