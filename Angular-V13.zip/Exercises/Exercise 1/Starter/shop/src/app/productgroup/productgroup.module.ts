import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


// TODO: 3
// Create an angular module named ProductgroupModule
// Import the CommonModule from @angular/common
// Register the ProductgroupListComponent in the ProductGroupModule and make it public
