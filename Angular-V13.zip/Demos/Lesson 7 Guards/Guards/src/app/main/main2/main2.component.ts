import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main2',
  template: `<h1>Main 2</h1>`,
  styles: []
})
export class Main2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
