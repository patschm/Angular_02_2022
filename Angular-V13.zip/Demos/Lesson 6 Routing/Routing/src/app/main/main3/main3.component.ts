import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main3',
  template: `<h1>Main 3</h1>`,
  styles: []
})
export class Main3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
