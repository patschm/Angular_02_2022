import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-reactive></app-reactive>
  `,
  styles: []
})
export class AppComponent {
  title = 'Reactive';
}
