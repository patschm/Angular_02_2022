import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-forms></app-forms>
  `,
  styles: []
})
export class AppComponent {
  title = 'Template';
}
