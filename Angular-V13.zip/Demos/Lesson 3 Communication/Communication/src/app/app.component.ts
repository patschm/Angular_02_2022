import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-communication></app-communication>
  `,
  styles: []
})
export class AppComponent {
  title = 'Communication';
}
