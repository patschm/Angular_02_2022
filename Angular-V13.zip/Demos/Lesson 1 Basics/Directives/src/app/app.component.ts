import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-basics><app-basics>
  `,
  styles: []
})
export class AppComponent {
  title = 'Directives';
}
