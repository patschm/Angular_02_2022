import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <app-binding></app-binding>
  `,
  styles: []
})
export class AppComponent {
  title = 'Bindings';
}
