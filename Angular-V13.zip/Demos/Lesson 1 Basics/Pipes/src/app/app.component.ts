import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <app-pipes></app-pipes>
  `,
  styles: []
})
export class AppComponent {
  title = 'Pipes';
}
