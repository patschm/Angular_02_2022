export class Message
{
    index:number = 0;
    text?:string;
}